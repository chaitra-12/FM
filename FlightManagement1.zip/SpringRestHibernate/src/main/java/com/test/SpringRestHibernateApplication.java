package com.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestHibernateApplication.class, args);
	}

}
