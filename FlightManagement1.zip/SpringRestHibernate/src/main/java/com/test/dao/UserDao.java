package com.test.dao;
import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;
import com.test.entities.Users;;

public interface UserDao extends CrudRepository<Users, BigInteger>{

}