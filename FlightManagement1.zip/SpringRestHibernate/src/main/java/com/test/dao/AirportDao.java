package com.test.dao;

import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;
import com.test.entities.Airport;

@Repository
public interface AirportDao extends CrudRepository<Airport, String> {

}
